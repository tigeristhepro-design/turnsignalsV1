# Vehicle Turn Signals & Hazards Mod (SHVDN3)

A lightweight, highly optimized, and responsive turn signal and hazard light script for Grand Theft Auto V. Drive realistically through Los Santos with fully functional exterior indicator lights that seamlessly hook into your vehicle's engine.

Built strictly on universal native engine hashes using Script Hook V .NET v3, this script features intelligent context switching—ensuring your controls never conflict when you are on foot versus when you are driving.

---

## 🎮 Controls & Features

The mod works natively on both **Keyboard** and **Controllers** by reading the game's built-in vehicle actions:

*   **Left Turn Signal:** Press **Q** *(or D-Pad Left)* while driving to toggle the left exterior blinker.
*   **Right Turn Signal:** Press **E** *(or D-Pad Right)* while driving to toggle the right exterior blinker.
*   **Hazard Lights:** Press **X** *(or D-Pad Down)* while driving to flash both indicator lights simultaneously.

*Note: Turning on a signal automatically cancels the opposite one. If you turn on your hazards, any active individual turn signals will immediately reset.*

---

## 🛠️ Requirements

Before installing, ensure you have the following prerequisites installed in your main Grand Theft Auto V directory:

1.  [Script Hook V](http://dev-c.com) (Latest Version)
2.  [Script Hook V .NET v3 (SHVDN3)](https://github.com)

---

## 💾 Installation Process

Follow these simple steps to install the mod:

1.  Download the mod's `.zip` archive from the release section.
2.  Extract the file to locate **`IndicatorMod.dll`** (or your unified compiled `.dll` file).
3.  Navigate to your main **Grand Theft Auto V installation directory** (where your `GTA5.exe` is located).
    *   *Steam Path default:* `C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V\`
    *   *Epic Games Path default:* `C:\Program Files\Epic Games\GTAV\`
    *   *Rockstar Launcher default:* `C:\Program Files\Rockstar Games\Grand Theft Auto V\`
4.  Open the folder named **`scripts`**. If a `scripts` folder does not exist, right-click in the directory, create a new folder, and name it exactly `scripts`.
5.  Drag and drop your compiled **`.dll`** file directly inside the `scripts` folder.
6.  Launch the game. If you are already in-game, press the **Insert** key on your keyboard to reload your scripts and activate the blinkers!

---

## 🖥️ Compatibility
*   **Legacy Edition:** Fully supported out of the box using ScriptHookVDotNet3.
*   **Enhanced Edition:** Fully supported when using community-updated *Script Hook V .NET Enhanced (SHVDNE)* interpreters.
*   **Smart Overlap Protection:** This script natively detects if you are the driver of the vehicle. Passengers or players on foot will not accidentally trigger the lights.
